# HOrcus: Open Source Intelligence

One place to find food, water, shelter, health and safety from free public sources.

HOrcus is a static web page with no build step, no accounts and no trackers. It bundles:

- Emergency numbers for 197 countries, with a 3D globe to pick a country
- Eight need categories (food, clean water, shelter, healthcare, safety, money and work, learning, power and connection) with practical tips and OpenStreetMap searches
- A directory of 15 free and open data sources (OpenStreetMap, USGS earthquakes, NASA FIRMS, GDACS, ReliefWeb, WHO and more)
- **Horus**, an optional voice and text assistant

## Run it

Open `index.html` in a browser, or serve the folder:

```
python3 -m http.server 8000
```

Keep `three.min.js` next to `index.html`. The globe needs it.

## Deploy on GitHub Pages

1. Push these files to a repository.
2. Go to **Settings > Pages**, choose the `main` branch and the `/ (root)` folder, then save.
3. The site appears at `https://<username>.github.io/<repo>/`.

## Horus and your API key

Horus is bring-your-own-key. Paste your own [Anthropic API key](https://console.anthropic.com) into the page. Usage is billed to your key, normally a fraction of a cent per question.

- The key is stored in your browser's `localStorage` and sent only to `api.anthropic.com`. There is no server and no analytics.
- Use **Change key** in the page to replace it. Clearing your browser's site data removes it.
- On GitHub Pages every project under `<username>.github.io` shares one browser origin, so other pages on the same account could read the stored key. Use a custom domain if that matters to you, and never reuse a key you share with others.
- Horus has no live data. It is told never to invent addresses, hours or phone numbers, and it can still make mistakes.
- The default model is `claude-haiku-4-5-20251001`. Users can enter a different model name in the key panel.

## Important notice

Emergency numbers and tips are hand-compiled general guidance. They may be outdated or differ locally. Verify them, and in a real emergency contact local services directly. Nothing here is medical, legal or professional advice. Corrections are welcome as issues or pull requests.

## Privacy

No cookies, no accounts, no trackers. `localStorage` holds only your chosen country, voice, and (if you use Horus) your key and model. Links to outside sources open in a new tab and are governed by those sites. Voice input uses your browser's speech recognition, which some browsers process on their vendor's servers.

## Credits

- [three.js](https://threejs.org) r128, MIT License, bundled as `three.min.js`
- Map links: [OpenStreetMap](https://www.openstreetmap.org) contributors
- All listed sources belong to their respective owners.

## License

[MIT](LICENSE)
